from .trace_clearance import TraceClearance
TraceClearance().register()
