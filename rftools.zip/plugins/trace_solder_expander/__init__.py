from .trace_solder_expander import Solder_Expander
Solder_Expander().register()
